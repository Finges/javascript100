/**
 ** Description: Project 1
 ** Author: Chris Lee
 ** Date: 10.5.16
 **
 **/



var name; // Create Variable
name = prompt("Hello! Please enter your name."); // Prompt for name
alert("Hello " + name); // Alert greeting
